# Saad Web

A native Android app that lets you log into and switch between **up to 4 separate
WhatsApp Web accounts**, each fully isolated (its own login, its own storage),
loaded from `web.whatsapp.com` in forced desktop mode.

## How it works (technical)

- Each account "slot" runs in its **own Android process**
  (`Slot1Activity` … `Slot4Activity`, declared with `android:process=":slotN"`
  in `AndroidManifest.xml`).
- `SaadWebApplication.onCreate()` calls `WebView.setDataDirectorySuffix()`
  per-process, which gives each slot a completely separate cookie /
  localStorage / IndexedDB directory. That's what makes 4 independent
  WhatsApp Web logins possible in one app.
- Each `WebView` is set to a desktop Chrome user-agent string so
  `web.whatsapp.com` always renders its desktop UI, never the "open on your
  phone" mobile redirect.

## Building the APK — no computer required

You don't need Android Studio. GitHub will build the APK for you.

**বাংলায়:**

1. মোবাইল ব্রাউজারে **github.com**-এ যান, লগইন করুন, এবং একটি নতুন **repository**
   তৈরি করুন (নাম যা খুশি দিন, যেমন `saad-web-app`)।
2. রিপোতে ঢুকে **Add file → Upload files**-এ ক্লিক করুন। আমি যে `project.zip`
   ফাইলটা দিয়েছি সেটা আপলোড করে **Commit changes** করুন। (Zip extract করার
   দরকার নেই — GitHub নিজেই এটা build-এর সময় extract করবে।)
3. আবার **Add file → Create new file**-এ ক্লিক করুন। ফাইলের নামের জায়গায় পুরো
   path লিখুন: `.github/workflows/build-apk.yml`
   তারপর আমি যে workflow ফাইলের কন্টেন্ট দিয়েছি সেটা কপি-পেস্ট করে **Commit**
   করুন।
4. Commit করার সাথে সাথে GitHub Actions অটোমেটিক build শুরু করবে। রিপোর উপরে
   **Actions** ট্যাবে গিয়ে progress দেখতে পারবেন (২-৪ মিনিট সময় লাগবে)।
5. Build শেষ হলে রিপোর ডান পাশে **Releases** সেকশনে (বা Actions run-এর ভিতরে
   Artifacts-এ) `.apk` ফাইল পাবেন। সেটা ট্যাপ করে ডাউনলোড করুন।
6. ফোনে APK ইনস্টল করার সময় "Install unknown apps" পারমিশন চাইলে সেটা allow
   করুন। ব্যস, অ্যাপ রেডি!

**English:**

1. On your phone's browser, go to **github.com**, log in, and create a new
   **repository** (any name, e.g. `saad-web-app`).
2. Inside the repo, tap **Add file → Upload files** and upload the
   `project.zip` I gave you, then **Commit changes**. (No need to extract the
   zip yourself — the build workflow extracts it automatically.)
3. Tap **Add file → Create new file**. For the filename, type the full path:
   `.github/workflows/build-apk.yml`
   Paste in the workflow content I gave you, then **Commit**.
4. GitHub Actions will start building automatically. Watch progress under the
   **Actions** tab (takes 2–4 minutes).
5. Once done, open the **Releases** section on the repo's right sidebar (or
   the Artifacts of the finished Actions run) and download the `.apk` file
   directly.
6. When installing, allow "Install unknown apps" if your phone asks. Done —
   open **Saad Web** and tap any of the 4 account cards to log in with a QR
   code, just like WhatsApp Web on a computer. Long-press a card to rename it
   (e.g. "Personal", "Business", "Shop").

## Notes / limitations

- Voice & video calls are not supported inside a WebView (WhatsApp Web's
  calling feature needs the real desktop browser). Chat, media, and file
  sharing all work normally.
- Each slot is linked as a separate WhatsApp "linked device" — WhatsApp
  allows up to 4 linked devices per phone number, which matches the 4 slots
  here.
- minSdk is 28 (Android 9+), required for the per-process storage isolation
  API.
