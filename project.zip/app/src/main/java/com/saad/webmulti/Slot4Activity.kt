package com.saad.webmulti

/**
 * Account slot 4 — runs in its own process (":slot4"), giving it a
 * completely separate WhatsApp Web session/storage from the other slots.
 */
class Slot4Activity : BaseWhatsAppActivity()
