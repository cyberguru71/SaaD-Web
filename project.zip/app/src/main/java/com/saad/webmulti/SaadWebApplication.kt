package com.saad.webmulti

import android.app.Application
import android.webkit.WebView

/**
 * Every account "slot" (Slot1Activity..Slot4Activity) runs in its own Android
 * process (declared in AndroidManifest via android:process=":slotN").
 *
 * WebView.setDataDirectorySuffix() gives each process a completely separate
 * cookie/localStorage/IndexedDB directory, so each slot is a fully isolated
 * WhatsApp Web session — logging into Account 1 never affects Account 2, 3, or 4.
 *
 * This MUST be called before any WebView object is created in the process,
 * which is why it happens here in Application.onCreate().
 */
class SaadWebApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        val processName = getProcessName()
        if (processName != packageName && processName.contains(":")) {
            val suffix = processName.substringAfterLast(":")
            WebView.setDataDirectorySuffix(suffix)
        }
    }
}
