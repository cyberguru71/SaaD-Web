package com.saad.webmulti

import android.content.Context

/**
 * Stores the user-editable display name for each of the 4 account slots.
 * Only read/written from MainActivity (the main process), purely for display.
 */
object AccountPrefs {
    private const val PREFS_NAME = "saad_web_slot_names"

    fun getName(context: Context, slot: Int): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString("slot_$slot", null)
            ?: context.getString(R.string.default_slot_name, slot)
    }

    fun setName(context: Context, slot: Int, name: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString("slot_$slot", name).apply()
    }
}
