package com.saad.webmulti

/**
 * Account slot 1 — runs in its own process (":slot1"), giving it a
 * completely separate WhatsApp Web session/storage from the other slots.
 */
class Slot1Activity : BaseWhatsAppActivity()
