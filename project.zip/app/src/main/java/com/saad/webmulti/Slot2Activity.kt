package com.saad.webmulti

/**
 * Account slot 2 — runs in its own process (":slot2"), giving it a
 * completely separate WhatsApp Web session/storage from the other slots.
 */
class Slot2Activity : BaseWhatsAppActivity()
