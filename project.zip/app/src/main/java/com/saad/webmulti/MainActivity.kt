package com.saad.webmulti

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val slotActivities = arrayOf(
        Slot1Activity::class.java,
        Slot2Activity::class.java,
        Slot3Activity::class.java,
        Slot4Activity::class.java
    )

    private lateinit var container: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        container = findViewById(R.id.slotContainer)
        renderSlots()
    }

    override fun onResume() {
        super.onResume()
        // Refresh names in case the user renamed one and came back
        renderSlots()
    }

    private fun renderSlots() {
        container.removeAllViews()
        val inflater = LayoutInflater.from(this)
        for (slot in 1..4) {
            val card = inflater.inflate(R.layout.item_account_card, container, false)
            val title = card.findViewById<TextView>(R.id.slotTitle)
            title.text = AccountPrefs.getName(this, slot)

            card.setOnClickListener { openSlot(slot) }
            card.setOnLongClickListener {
                showRenameDialog(slot)
                true
            }
            container.addView(card)
        }
    }

    private fun openSlot(slot: Int) {
        val intent = Intent(this, slotActivities[slot - 1])
        intent.putExtra(EXTRA_SLOT_NAME, AccountPrefs.getName(this, slot))
        startActivity(intent)
    }

    private fun showRenameDialog(slot: Int) {
        val input = EditText(this)
        input.setText(AccountPrefs.getName(this, slot))
        input.setSelection(input.text.length)

        val padding = (16 * resources.displayMetrics.density).toInt()
        val wrapper = LinearLayout(this)
        wrapper.setPadding(padding, padding, padding, 0)
        wrapper.addView(input)
        input.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )

        AlertDialog.Builder(this)
            .setTitle(R.string.rename_title)
            .setView(wrapper)
            .setPositiveButton(R.string.save) { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotEmpty()) {
                    AccountPrefs.setName(this, slot, newName)
                    renderSlots()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    companion object {
        const val EXTRA_SLOT_NAME = "extra_slot_name"
    }
}
