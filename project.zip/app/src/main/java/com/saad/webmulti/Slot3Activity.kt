package com.saad.webmulti

/**
 * Account slot 3 — runs in its own process (":slot3"), giving it a
 * completely separate WhatsApp Web session/storage from the other slots.
 */
class Slot3Activity : BaseWhatsAppActivity()
